# Karo Online — Customer App (पहला version)

पूरा prototype ऐप के अंदर पैक है (assets/web/index.html), इसलिए ऐप बिल्कुल prototype जैसी चलती है।
Videos, photo upload, WhatsApp/Call links ऐप के अंदर से काम करते हैं।

## फ़ोन से APK बनाना
1. github.com पर नया **Private** repo बनाएँ (नाम: karo-online-app), "Add a README" ✓
2. Add file → Upload files → **karo_customer.zip** (बिना खोले) → Commit
3. Add file → Create new file → नाम: `.github/workflows/build.yml` → build.yml का text paste → Commit
4. Actions → "Build Customer APK" अपने-आप चलेगा (10–12 मिनट)
5. Run पर tap → नीचे Artifacts → **karo-online-apk** डाउनलोड → ZIP खोलें → app-release.apk install करें

ध्यान दें: यह prototype है, data demo वाला है (असली backend अगली किस्त में)।
